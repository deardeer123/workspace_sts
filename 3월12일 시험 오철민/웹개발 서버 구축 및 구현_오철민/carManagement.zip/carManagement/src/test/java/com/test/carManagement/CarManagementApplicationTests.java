package com.test.carManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
